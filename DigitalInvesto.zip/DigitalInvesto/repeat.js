

<script>

    const ar = [4,3,6,3,4,3]

    function findrepitation(ar){
        let counts = {}

        for(let i =0; i < ar.length; i++){ 
         if (counts[ar[i]]){
           counts[ar[i]] += 1
         } else {
          counts[ar[i]] = 1
         }
        }  
       for (let x in counts){
        if (counts[x] >= 2){
            console.log(x)
        }
       }
       
    }

    findrepitation(ar)

</script>
