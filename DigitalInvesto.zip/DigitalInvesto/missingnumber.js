<script>

	
	function findNo(arr, n) {

		let total = Math.floor((n + 1) * (n + 2) / 2);
                let sum=0;
		for (let i = 0; i < n; i++)
			sum+= arr[i];
		return total-sum;
	}

	 

	let arr = [ 1, 2, 4, 5, 6 ];
	let n = arr.length;
	let miss = findNo(arr, n);
	document.write(miss);

 

</script>
